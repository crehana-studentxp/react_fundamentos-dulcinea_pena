import React from "react";
import styles from "./Checkout.module.css";

const AddressForm = React.forwardRef((props, ref) => {
	const {handlePayClick} = props;

	return (
		<React.Fragment>
			<form onSubmit={() => handlePayClick("Procesando Pago")}>
				<p className={styles.subtitle}>Dirección de envío</p>
				<div className={styles.flex}>
					<p>Calle</p>
					<input
						type="text"
						name="address"
						ref={ref}
						className={styles.addressInput}
					/>
				</div>
				<button type="submit" className={styles.payButton}>Proceder al Pago</button>
			</form>
		</React.Fragment>
	)
})

export default AddressForm;