import React from "react";

const Header = () => {
	const [loggedIn, setLoggedIn] = React.useState(false);
	const h1Styles = {
		color: 'darkslateblue',
    fontWeight: 200,
	};

	return (
		<React.Fragment>
			<h1 style={h1Styles}>Electrónicos Online</h1>
			<div style={{ display: 'flex'}}>
				<div>
					<p>Contacto: electronicosonline@mitienda.com</p>
				</div>
				{loggedIn ? (
					<button onClick={() => setLoggedIn(false)}>Cerrar sesión</button>
				) : (
					<button onClick={() => setLoggedIn(true)}>Iniciar sesión</button>
				)}
				{loggedIn && <p>Dulcinea</p>}
			</div>
		</React.Fragment>
	)
}

export default Header;