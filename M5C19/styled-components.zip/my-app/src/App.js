import React from 'react';
import './index.css';
import Cart from './Checkout/Cart.jsx';
import Catalog from './Catalog/Catalog';
import Header from './Header/Header';

function App() {
  const [activePromo, setActivePromo] = React.useState(false);

  React.useEffect(() => {
    let timer = setTimeout(() => setActivePromo(true), 4000);

    return () => {
      clearTimeout(timer);
    };
  }, []);

  return (
    <React.Fragment>
      <div className='header-container'>
        <Header />
      </div>
      <aside className='cart-section'>
        <Cart user={"Dulcinea"}/>
      </aside>
      <section className='catalog-section'>
        <Catalog activePromo={activePromo} />
      </section>
      
    </React.Fragment>
  );
}

export default App;
