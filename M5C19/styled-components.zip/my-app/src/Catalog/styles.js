import styled from "styled-components";

export const ItemWrapper = styled.div`
  width: 400px;
  padding: 10px;
  box-shadow: box-shadow: 5px 10px #888888;
  box-shadow: rgb(0 0 0 / 10%) 0px 4px 6px -1px, rgb(0 0 0 / 6%) 0px 2px 4px -1px;
  display: inline-block;
  margin-right: 30px;
  background-color: #f3f4fb;

  & div:first-child {
    height: 120px;
  }

  & p:first-child {
    color: #6f6fbe;
    text-align: right;
    font-size: 11px;
  }

  & p:nth-child(3){
    font-size: 24px;
    text-align: right;
    color: #8e7777;
    margin-bottom: 10px;
    margin-top: 10px;
  }

  & span {
    color: #a8302f;
    border-bottom: 3px solid #f1c179;
    padding: 3px 11px;
  }
`;