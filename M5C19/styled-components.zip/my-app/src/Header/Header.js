import React from "react";
import { StyledButton } from "./styles";

const Header = () => {
	const [loggedIn, setLoggedIn] = React.useState(false);
	const h1Styles = {
		color: 'darkslateblue',
    fontWeight: 200,
	};

	return (
		<React.Fragment>
			<h1 style={h1Styles}>Electrónicos Online</h1>
			<div style={{ display: 'flex', alignItems: 'center'}}>
				<div style={{ padding: '0 85px', color: '#9b9595' }}>
					<p>electronicosonline@mitienda.com</p>
				</div>
				{loggedIn ? (
					<StyledButton onClick={() => setLoggedIn(false)}>Cerrar sesión</StyledButton>
				) : (
					<StyledButton primary onClick={() => setLoggedIn(true)}>Iniciar sesión</StyledButton>
				)}
				{loggedIn && <p>Dulcinea</p>}
			</div>
		</React.Fragment>
	)
}

export default Header;