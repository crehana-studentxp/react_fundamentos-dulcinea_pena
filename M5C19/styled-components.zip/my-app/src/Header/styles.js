import styled from "styled-components";

export const StyledButton = styled.button`
  border: none;
  background-color: transparent;
  font-weight: bold;
  font-size: 15px;
  color: ${(props) => (props.primary ? "#1455d4;" : "black")};
`;