import React from "react";

const Header = () => {
	const [loggedIn, setLoggedIn] = React.useState(false);

	return (
		<React.Fragment>
			<h1>Electrónicos Online</h1>
			<div>
				<p>Contacto: electronicosonline@mitienda.com</p>
			</div>
			{loggedIn ? (
				<button onClick={() => setLoggedIn(false)}>Cerrar sesión</button>
			) : (
				<button onClick={() => setLoggedIn(true)}>Iniciar sesión</button>
			)}
			{loggedIn && <p>Dulcinea</p>}
		</React.Fragment>
	)
}

export default Header;