import React from "react";


const ItemCard = (props) => {
	const {name, price, children} = props;

	return (
		<div>
			<p>Categoría Hogar</p>
			<p>{name}</p>
			<p>Precio: $ {price}</p>
			{children}
			<br/>
			<br/>
			<br/>
		</div>
	)
}

export default ItemCard;