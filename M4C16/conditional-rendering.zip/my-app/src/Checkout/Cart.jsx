import React from "react";
import AddressForm from "./AddressForm";

let update;
class Cart extends React.Component {
	constructor(props) {
    super(props);
    this.state = {
			items: [],
			freeShip: false,
			freeShipMessage: "No incluídos costos de envío",
			address: ""
		};
		this.inputRef = React.createRef();
  }
	
	componentDidMount = () => {
		fetch('https://fakestoreapi.com/carts/5')
			.then(res => res.json())
			.then(json => this.setState({ items: json.products }));

		update = setTimeout(() => { 
			this.setState({ freeShip: true });
		}, 5000);
	}

	componentDidUpdate = (prevProps, prevState) => { 
		if (prevState.freeShip !== this.state.freeShip) {
			if (this.state.freeShip) { 
				this.setState({ freeShipMessage: "Tienes envío gratis" });
			}
		}
	}

	componentWillUnmount = () => {
		clearTimeout(update);
	}

	handleAddressChange = (event) => {
		this.setState({ address: event.target.value });
	}

	handlePayClick = (message) => {
		this.inputRef.current && alert(message + ', se enviará a: ' + this.inputRef.current.value);
	}


	render () {
		return (
			<React.Fragment>
				<h3>Tus compras, {this.props.user}</h3>
				<ul>
					{this.state.items.map((element, item) => {
						return (
							<li key={item}>
								<p>Artículo {element.productId}</p>
								<p>Cantidad: {element.quantity}</p>
							</li>
						)
					})}
				</ul>
				<p>{this.state.freeShipMessage}</p>
				<AddressForm 
					handleAddressChange={this.handleAddressChange} 
					address={this.state.address} 
					handlePayClick={this.handlePayClick} 
					ref={this.inputRef}
				/>
			</React.Fragment>
		)
	}
}

export default Cart;