import React from "react";

const AddressForm = React.forwardRef((props, ref) => {
	const {handlePayClick} = props;

	return (
		<React.Fragment>
			<form onSubmit={() => handlePayClick("Procesando Pago")}>
				<p>Dirección de envío</p>
				<p>Calle</p>
				<input
					type="text"
					name="address"
					ref={ref}
				/>
				<button type="submit">Proceder al Pago</button>
			</form>
		</React.Fragment>
	)
})

export default AddressForm;