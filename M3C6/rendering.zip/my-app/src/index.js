import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

let seconds = 1;
function updateSeconds() {
  const element = (
    <div>
      <h1>Hello, world!</h1>
      <p>Han pasado {seconds++} segundos</p>
    </div>
  );
  ReactDOM.render(
    element,
    document.getElementById('root')
  );
}

setInterval(updateSeconds, 1000);