import React from "react";

class Cart extends React.Component {
	constructor(props) {
    super(props);
    this.state = {
			items: [
        {productId: "233988", quantity: "2"},
        {productId: "233445", quantity: "1"}
      ],
			address: "Calle 1, Centro."
		};
  }

	render () {
		return (
			<React.Fragment>
				<h3>Tus compras, {this.props.user}</h3>
				<ul>
					{this.state.items.map((element, item) => {
            return (
              <li key={item}>
                <p>Artículo {element.productId}</p>
                <p>Cantidad: {element.quantity}</p>
              </li>
            )
          })}
				</ul>
				<div>
					<p>Dirección de envío</p>
					<p>{this.state.address}</p>
				</div>
				<button>Proceder al Pago</button>
			</React.Fragment>
		)
	}
}

export default Cart;