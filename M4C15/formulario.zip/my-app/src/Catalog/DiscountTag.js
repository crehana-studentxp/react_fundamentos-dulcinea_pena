import React from "react";

const DiscountTag = (props) => {
	return (
		<span>
			{props.discount}% off
		</span>
	)
}

export default DiscountTag;