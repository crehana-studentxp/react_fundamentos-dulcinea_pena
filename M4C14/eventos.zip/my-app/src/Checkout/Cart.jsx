import React from "react";

let update;
class Cart extends React.Component {
	constructor(props) {
    super(props);
    this.state = {
			items: [],
			freeShip: false,
			freeShipMessage: "No incluídos costos de envío",
			address: ""
		};
		
  }
	
	componentDidMount = () => {
		fetch('https://fakestoreapi.com/carts/5')
			.then(res => res.json())
			.then(json => this.setState({ items: json.products }));

		update = setTimeout(() => { 
			this.setState({ freeShip: true });
		}, 5000);
	}

	componentDidUpdate = (prevProps, prevState) => { 
		if (prevState.freeShip !== this.state.freeShip) {
			if (this.state.freeShip) { 
				this.setState({ freeShipMessage: "Tienes envío gratis" });
			}
		}
	}

	componentWillUnmount = () => {
		clearTimeout(update);
	}

	handleAddressChange = (event) => {
		this.setState({ address: event.target.value });
	}

	handlePayClick = (message) => {
		alert(message)
	}


	render () {
		return (
			<React.Fragment>
				<h3>Tus compras, {this.props.user}</h3>
				<ul>
					{this.state.items.map((element, item) => {
						return (
							<li key={item}>
								<p>Artículo {element.productId}</p>
								<p>Cantidad: {element.quantity}</p>
							</li>
						)
					})}
				</ul>
				<div>
					<p>Dirección de envío</p>
					<p>Calle</p>
					<input
						type="text"
						name="address"
						value={this.state.address}
						onChange={this.handleAddressChange}
					/>
				</div>
				<p>{this.state.freeShipMessage}</p>
				<button onClick={() => this.handlePayClick("Procesando Pago")}>Proceder al Pago</button>
			</React.Fragment>
		)
	}
}

export default Cart;