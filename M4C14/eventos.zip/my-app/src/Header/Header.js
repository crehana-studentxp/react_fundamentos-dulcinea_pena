import React from "react";

const Header = () => {
	return (
		<React.Fragment>
			<h1>Electrónicos Online</h1>
			<div>
				<p>Contacto: electronicosonline@mitienda.com</p>
			</div>
		</React.Fragment>
	)
}

export default Header;