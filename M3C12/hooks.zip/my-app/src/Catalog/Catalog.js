import React from "react";
import DiscountTag from "../DiscountTag";
import ItemCard from "./ItemCard";

const Catalog = (props) => {
	const [items, setItems] = React.useState([]);
	const [discount, setDiscount] = React.useState(30);
	
	React.useEffect(() => {
		fetch('https://fakestoreapi.com/products/category/electronics?limit=2')
			.then(res => res.json())
			.then(json => setItems(json));
	}, []);

	React.useEffect(() => {
		if (props.activePromo) {
			setDiscount(discount + 10);
		}
	}, [props.activePromo]);

	return (
		<React.Fragment>
			<p>Catálogo</p>
			{items.map((element, item) => {
				return (
					<React.Fragment key={item}>
						<ItemCard price={element.price} name={element.title}>
							<DiscountTag discount={discount} />
						</ItemCard>
					</React.Fragment>
				)
			})}
		</React.Fragment>
	)
}

export default Catalog;