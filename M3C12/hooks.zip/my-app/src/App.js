import React from 'react';
import Cart from './Checkout/Cart.jsx';
import Catalog from './Catalog/Catalog';
import Header from './Header/Header';

function App() {
  const [activePromo, setActivePromo] = React.useState(false);

  React.useEffect(() => {
    let timer = setTimeout(() => setActivePromo(true), 4000);

    return () => {
      clearTimeout(timer);
    };
  }, []);

  return (
    <React.Fragment>
      {/* <Header /> */}
      <Catalog activePromo={activePromo} />
      {/* <Cart user={"Dulcinea"}/> */}
    </React.Fragment>
  );
}

export default App;
