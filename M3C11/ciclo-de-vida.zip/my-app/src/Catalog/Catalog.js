import React from "react";
import DiscountTag from "./DiscountTag";
import ItemCard from "./ItemCard";

const Catalog = (props) => {
	return (
		<React.Fragment>
			<p>Catálogo</p>
			<ItemCard price={"5000"} name={"Usb"} discount={"30"}>
				<DiscountTag discount={"30"}/>
			</ItemCard>
    	<ItemCard price={"700"} name={"Teclado"}> 
				<DiscountTag discount={"50"}/>
			</ItemCard>
		</React.Fragment>
	)
}

export default Catalog;