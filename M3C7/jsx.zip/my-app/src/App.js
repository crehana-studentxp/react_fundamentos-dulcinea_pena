function App() {
  let year = '1990';

  const data = {
    day: '01',
    month: '11'
  };

  function generateBirthday(data) {
    return data.day + '-' + data.month + '-' + year;
  }

  return (
    <div className="App">
      <header className="App-header">
        <p>Fecha de nacimiento: {generateBirthday(data)}</p>
      </header>
    </div>
  );
}

export default App;