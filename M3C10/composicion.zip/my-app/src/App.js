import React from 'react';
import Cart from './Checkout/Cart.jsx';
import Catalog from './Catalog/Catalog';
import Header from './Header/Header';

function App() {
  return (
    <React.Fragment>
      <Header />
      <Catalog />
      <Cart user={"Dulcinea"}/>
    </React.Fragment>
  );
}

export default App;
