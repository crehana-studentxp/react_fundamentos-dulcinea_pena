import ItemCard from './ItemCard';
import React from 'react';

function App() {
  return (
    <React.Fragment>
      <ItemCard price={"5000"} name={"Usb"} discount={"30"}/>
      <ItemCard price={"700"} name={"Teclado"} discount={"60"}/>
    </React.Fragment>
  );
}

export default App;
