import React from "react";
import DiscountTag from "./DiscountTag";

const ItemCard = (props) => {
	console.log("dd", props)
	return (
		<div>
			<p>Categoría Electrónicos</p>
			<p>{props.name}</p>
			<p>Precio: $ {props.price}</p>
			<DiscountTag discount={props.discount}/>
			<br/>
			<br/>
			<br/>
		</div>
	)
}

export default ItemCard;